import java.util.ArrayList;
import java.util.List;

public class Quiz {
    String quizName;
    List<Question> questions;

    public Quiz(String quizName, List<Question> questions) {
        this.quizName = quizName;
        this.questions = new ArrayList<>();
    }

    public void addQuestion(List<Question> questions){
        Question question = new Question();
        questions.add(question);
    }

    public String getQuizName() {
        return quizName;
    }
}
