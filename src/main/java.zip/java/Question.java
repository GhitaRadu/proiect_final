import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

public class Question {
    String questionText;
    List<Answer> answers;
    Timer timer;

    public Question(String questionText, List<Answer> answers, Timer timer) {
        this.questionText = questionText;
        this.answers = new ArrayList<>();
        this.timer = timer;
    }

    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    public List<Answer> getAnswers() {
        return answers;
    }
}
